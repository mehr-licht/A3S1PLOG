
initialBoard([
    [black,empty,empty,empty,empty],
    [empty,white,white,empty,empty],
    [empty,empty,empty,white,empty],
    [white,empty,empty,empty,empty],
    [empty,empty,empty,empty,empty],
    [empty,black,black,empty,empty]
]).

symbol(empty,S) :- S ='.'.
symbol(black,S) :- S ='1'.
symbol(white,S) :- S ='2'.

printBoard(X):- nl, initialBoard(X), printMatrix(X, 1).

printMatrix([], 6).

%letter(N, L),
%write(L),
printMatrix([Head|Tail], N) :-   
    write(' '),   
    N1 is N + 1,
    write(' | '),
    printLine(Head),
    write('\n  |---|---|---|---|---|\n'),
    printMatrix(Tail, N1).

printLine([]).

printLine([Head|Tail]) :-
    symbol(Head, S),
    write(S),
    write(' | '),
    printLine(Tail).

