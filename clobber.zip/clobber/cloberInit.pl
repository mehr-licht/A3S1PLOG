:- consult('menuGame.pl').
:- consult('clobberDisplay.pl').
:- use_module(library(random)).
:- use_module(library(system)).

clobber :-
      mainMenu.

